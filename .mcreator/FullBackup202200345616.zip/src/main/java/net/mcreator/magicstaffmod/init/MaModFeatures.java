
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicstaffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.magicstaffmod.world.features.ores.WaterOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.StoneOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.StoneManaOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.StoneIceOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.ObsidianOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.FireOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.DeepslateManaOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.DeepslateIceOreFeature;
import net.mcreator.magicstaffmod.world.features.ores.ActiveSoulSandFeature;
import net.mcreator.magicstaffmod.MaMod;

@Mod.EventBusSubscriber
public class MaModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MaMod.MODID);
	public static final RegistryObject<Feature<?>> STONE_MANA_ORE = REGISTRY.register("stone_mana_ore", StoneManaOreFeature::feature);
	public static final RegistryObject<Feature<?>> DEEPSLATE_MANA_ORE = REGISTRY.register("deepslate_mana_ore", DeepslateManaOreFeature::feature);
	public static final RegistryObject<Feature<?>> WATER_ORE = REGISTRY.register("water_ore", WaterOreFeature::feature);
	public static final RegistryObject<Feature<?>> FIRE_ORE = REGISTRY.register("fire_ore", FireOreFeature::feature);
	public static final RegistryObject<Feature<?>> STONE_ORE = REGISTRY.register("stone_ore", StoneOreFeature::feature);
	public static final RegistryObject<Feature<?>> OBSIDIAN_ORE = REGISTRY.register("obsidian_ore", ObsidianOreFeature::feature);
	public static final RegistryObject<Feature<?>> STONE_ICE_ORE = REGISTRY.register("stone_ice_ore", StoneIceOreFeature::feature);
	public static final RegistryObject<Feature<?>> DEEPSLATE_ICE_ORE = REGISTRY.register("deepslate_ice_ore", DeepslateIceOreFeature::feature);
	public static final RegistryObject<Feature<?>> ACTIVE_SOUL_SAND = REGISTRY.register("active_soul_sand", ActiveSoulSandFeature::feature);
}
