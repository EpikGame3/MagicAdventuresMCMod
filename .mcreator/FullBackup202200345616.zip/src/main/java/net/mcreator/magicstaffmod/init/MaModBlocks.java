
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicstaffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.magicstaffmod.block.WaterOreBlock;
import net.mcreator.magicstaffmod.block.StoneOreBlock;
import net.mcreator.magicstaffmod.block.StoneManaOreBlock;
import net.mcreator.magicstaffmod.block.StoneIceOreBlock;
import net.mcreator.magicstaffmod.block.ObsidianOreBlock;
import net.mcreator.magicstaffmod.block.ManaBlockBlock;
import net.mcreator.magicstaffmod.block.HolySteelBlockBlock;
import net.mcreator.magicstaffmod.block.FireOreBlock;
import net.mcreator.magicstaffmod.block.DeepslateManaOreBlock;
import net.mcreator.magicstaffmod.block.DeepslateIceOreBlock;
import net.mcreator.magicstaffmod.block.ActiveSoulSandBlock;
import net.mcreator.magicstaffmod.MaMod;

public class MaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MaMod.MODID);
	public static final RegistryObject<Block> STONE_MANA_ORE = REGISTRY.register("stone_mana_ore", () -> new StoneManaOreBlock());
	public static final RegistryObject<Block> DEEPSLATE_MANA_ORE = REGISTRY.register("deepslate_mana_ore", () -> new DeepslateManaOreBlock());
	public static final RegistryObject<Block> MANA_BLOCK = REGISTRY.register("mana_block", () -> new ManaBlockBlock());
	public static final RegistryObject<Block> WATER_ORE = REGISTRY.register("water_ore", () -> new WaterOreBlock());
	public static final RegistryObject<Block> FIRE_ORE = REGISTRY.register("fire_ore", () -> new FireOreBlock());
	public static final RegistryObject<Block> STONE_ORE = REGISTRY.register("stone_ore", () -> new StoneOreBlock());
	public static final RegistryObject<Block> OBSIDIAN_ORE = REGISTRY.register("obsidian_ore", () -> new ObsidianOreBlock());
	public static final RegistryObject<Block> STONE_ICE_ORE = REGISTRY.register("stone_ice_ore", () -> new StoneIceOreBlock());
	public static final RegistryObject<Block> DEEPSLATE_ICE_ORE = REGISTRY.register("deepslate_ice_ore", () -> new DeepslateIceOreBlock());
	public static final RegistryObject<Block> ACTIVE_SOUL_SAND = REGISTRY.register("active_soul_sand", () -> new ActiveSoulSandBlock());
	public static final RegistryObject<Block> HOLY_STEEL_BLOCK = REGISTRY.register("holy_steel_block", () -> new HolySteelBlockBlock());
}
