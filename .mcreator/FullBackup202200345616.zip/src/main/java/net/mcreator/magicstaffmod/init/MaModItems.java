
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicstaffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.magicstaffmod.item.WaterStaffItem;
import net.mcreator.magicstaffmod.item.WaterIngotItem;
import net.mcreator.magicstaffmod.item.WaterEssentionItem;
import net.mcreator.magicstaffmod.item.WaterCrystalItem;
import net.mcreator.magicstaffmod.item.VTE7Item;
import net.mcreator.magicstaffmod.item.UncompliteHolyBladeItem;
import net.mcreator.magicstaffmod.item.TrueGungnirItem;
import net.mcreator.magicstaffmod.item.TrueExcaliburItem;
import net.mcreator.magicstaffmod.item.StoneStaffItem;
import net.mcreator.magicstaffmod.item.StoneEssentionItem;
import net.mcreator.magicstaffmod.item.StoneCrystalItem;
import net.mcreator.magicstaffmod.item.StoneBattleAxeItem;
import net.mcreator.magicstaffmod.item.StoneAxeBladeItem;
import net.mcreator.magicstaffmod.item.SoulStringItem;
import net.mcreator.magicstaffmod.item.SoulStaffItem;
import net.mcreator.magicstaffmod.item.SoulShardItem;
import net.mcreator.magicstaffmod.item.SoulEssentionItem;
import net.mcreator.magicstaffmod.item.SoulCrystalItem;
import net.mcreator.magicstaffmod.item.ObsidianedHevyHolyArmorItem;
import net.mcreator.magicstaffmod.item.ObsidianStaffItem;
import net.mcreator.magicstaffmod.item.ObsidianPlateItem;
import net.mcreator.magicstaffmod.item.ObsidianEssentionItem;
import net.mcreator.magicstaffmod.item.ObsidianCrystalItem;
import net.mcreator.magicstaffmod.item.ManaNecklaceItem;
import net.mcreator.magicstaffmod.item.ManaCrystalItem;
import net.mcreator.magicstaffmod.item.ManaChocolateItem;
import net.mcreator.magicstaffmod.item.ManaChocolateChunkItem;
import net.mcreator.magicstaffmod.item.ManaBeltItem;
import net.mcreator.magicstaffmod.item.IceStaffItem;
import net.mcreator.magicstaffmod.item.IceKatanaItem;
import net.mcreator.magicstaffmod.item.IceEssentionItem;
import net.mcreator.magicstaffmod.item.IceCrystalItem;
import net.mcreator.magicstaffmod.item.IceBladeItem;
import net.mcreator.magicstaffmod.item.HolyWaterItem;
import net.mcreator.magicstaffmod.item.HolyStringItem;
import net.mcreator.magicstaffmod.item.HolyRodItem;
import net.mcreator.magicstaffmod.item.HolyPlateItem;
import net.mcreator.magicstaffmod.item.HolyPickaxeItem;
import net.mcreator.magicstaffmod.item.HolyNuggetItem;
import net.mcreator.magicstaffmod.item.HolyKatanaItem;
import net.mcreator.magicstaffmod.item.HolyIngotItem;
import net.mcreator.magicstaffmod.item.HolyHolyCastingHammerItem;
import net.mcreator.magicstaffmod.item.HolyHammerObsidianedItem;
import net.mcreator.magicstaffmod.item.HolyHammerItem;
import net.mcreator.magicstaffmod.item.HolyGardItem;
import net.mcreator.magicstaffmod.item.HolyCastItem;
import net.mcreator.magicstaffmod.item.HolyBowUpItem;
import net.mcreator.magicstaffmod.item.HolyBowItem;
import net.mcreator.magicstaffmod.item.HolyBladeItem;
import net.mcreator.magicstaffmod.item.HolyBattleAxeItem;
import net.mcreator.magicstaffmod.item.HolyAxeItem;
import net.mcreator.magicstaffmod.item.HolyAxeBladeItem;
import net.mcreator.magicstaffmod.item.HeavyHolyArmorItem;
import net.mcreator.magicstaffmod.item.GungnirItem;
import net.mcreator.magicstaffmod.item.FireStaffItem;
import net.mcreator.magicstaffmod.item.FireIngotItem;
import net.mcreator.magicstaffmod.item.FireGardItem;
import net.mcreator.magicstaffmod.item.FireEssentionItem;
import net.mcreator.magicstaffmod.item.FireCrystalItem;
import net.mcreator.magicstaffmod.item.ExcaliburItem;
import net.mcreator.magicstaffmod.item.ConcentratedManaCrystalItem;
import net.mcreator.magicstaffmod.item.BrockenManaCrystalItem;
import net.mcreator.magicstaffmod.MaMod;

public class MaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MaMod.MODID);
	public static final RegistryObject<Item> CONCENTRATED_MANA_CRYSTAL = REGISTRY.register("concentrated_mana_crystal",
			() -> new ConcentratedManaCrystalItem());
	public static final RegistryObject<Item> STONE_STAFF = REGISTRY.register("stone_staff", () -> new StoneStaffItem());
	public static final RegistryObject<Item> FIRE_STAFF = REGISTRY.register("fire_staff", () -> new FireStaffItem());
	public static final RegistryObject<Item> WATER_STAFF = REGISTRY.register("water_staff", () -> new WaterStaffItem());
	public static final RegistryObject<Item> ICE_STAFF = REGISTRY.register("ice_staff", () -> new IceStaffItem());
	public static final RegistryObject<Item> OBSIDIAN_STAFF = REGISTRY.register("obsidian_staff", () -> new ObsidianStaffItem());
	public static final RegistryObject<Item> SOUL_STAFF = REGISTRY.register("soul_staff", () -> new SoulStaffItem());
	public static final RegistryObject<Item> HOLY_BOW = REGISTRY.register("holy_bow", () -> new HolyBowItem());
	public static final RegistryObject<Item> HOLY_BOW_UP = REGISTRY.register("holy_bow_up", () -> new HolyBowUpItem());
	public static final RegistryObject<Item> STONE_MANA_ORE = block(MaModBlocks.STONE_MANA_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> DEEPSLATE_MANA_ORE = block(MaModBlocks.DEEPSLATE_MANA_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> BROCKEN_MANA_CRYSTAL = REGISTRY.register("brocken_mana_crystal", () -> new BrockenManaCrystalItem());
	public static final RegistryObject<Item> MANA_CRYSTAL = REGISTRY.register("mana_crystal", () -> new ManaCrystalItem());
	public static final RegistryObject<Item> MANA_BLOCK = block(MaModBlocks.MANA_BLOCK, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> WATER_ORE = block(MaModBlocks.WATER_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> WATER_ESSENTION = REGISTRY.register("water_essention", () -> new WaterEssentionItem());
	public static final RegistryObject<Item> WATER_CRYSTAL = REGISTRY.register("water_crystal", () -> new WaterCrystalItem());
	public static final RegistryObject<Item> WATER_INGOT = REGISTRY.register("water_ingot", () -> new WaterIngotItem());
	public static final RegistryObject<Item> FIRE_ORE = block(MaModBlocks.FIRE_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> FIRE_ESSENTION = REGISTRY.register("fire_essention", () -> new FireEssentionItem());
	public static final RegistryObject<Item> FIRE_CRYSTAL = REGISTRY.register("fire_crystal", () -> new FireCrystalItem());
	public static final RegistryObject<Item> FIRE_INGOT = REGISTRY.register("fire_ingot", () -> new FireIngotItem());
	public static final RegistryObject<Item> FIRE_GARD = REGISTRY.register("fire_gard", () -> new FireGardItem());
	public static final RegistryObject<Item> STONE_ORE = block(MaModBlocks.STONE_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> STONE_ESSENTION = REGISTRY.register("stone_essention", () -> new StoneEssentionItem());
	public static final RegistryObject<Item> STONE_CRYSTAL = REGISTRY.register("stone_crystal", () -> new StoneCrystalItem());
	public static final RegistryObject<Item> STONE_AXE_BLADE = REGISTRY.register("stone_axe_blade", () -> new StoneAxeBladeItem());
	public static final RegistryObject<Item> OBSIDIAN_ORE = block(MaModBlocks.OBSIDIAN_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> OBSIDIAN_ESSENTION = REGISTRY.register("obsidian_essention", () -> new ObsidianEssentionItem());
	public static final RegistryObject<Item> OBSIDIAN_CRYSTAL = REGISTRY.register("obsidian_crystal", () -> new ObsidianCrystalItem());
	public static final RegistryObject<Item> OBSIDIAN_PLATE = REGISTRY.register("obsidian_plate", () -> new ObsidianPlateItem());
	public static final RegistryObject<Item> STONE_ICE_ORE = block(MaModBlocks.STONE_ICE_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> DEEPSLATE_ICE_ORE = block(MaModBlocks.DEEPSLATE_ICE_ORE, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> ICE_ESSENTION = REGISTRY.register("ice_essention", () -> new IceEssentionItem());
	public static final RegistryObject<Item> ICE_CRYSTAL = REGISTRY.register("ice_crystal", () -> new IceCrystalItem());
	public static final RegistryObject<Item> ICE_BLADE = REGISTRY.register("ice_blade", () -> new IceBladeItem());
	public static final RegistryObject<Item> ACTIVE_SOUL_SAND = block(MaModBlocks.ACTIVE_SOUL_SAND, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> SOUL_ESSENTION = REGISTRY.register("soul_essention", () -> new SoulEssentionItem());
	public static final RegistryObject<Item> SOUL_SHARD = REGISTRY.register("soul_shard", () -> new SoulShardItem());
	public static final RegistryObject<Item> SOUL_CRYSTAL = REGISTRY.register("soul_crystal", () -> new SoulCrystalItem());
	public static final RegistryObject<Item> SOUL_STRING = REGISTRY.register("soul_string", () -> new SoulStringItem());
	public static final RegistryObject<Item> HOLY_WATER = REGISTRY.register("holy_water", () -> new HolyWaterItem());
	public static final RegistryObject<Item> HOLY_INGOT = REGISTRY.register("holy_ingot", () -> new HolyIngotItem());
	public static final RegistryObject<Item> HOLY_NUGGET = REGISTRY.register("holy_nugget", () -> new HolyNuggetItem());
	public static final RegistryObject<Item> HOLY_CAST = REGISTRY.register("holy_cast", () -> new HolyCastItem());
	public static final RegistryObject<Item> HOLY_ROD = REGISTRY.register("holy_rod", () -> new HolyRodItem());
	public static final RegistryObject<Item> HOLY_PLATE = REGISTRY.register("holy_plate", () -> new HolyPlateItem());
	public static final RegistryObject<Item> HOLY_STRING = REGISTRY.register("holy_string", () -> new HolyStringItem());
	public static final RegistryObject<Item> HOLY_BLADE = REGISTRY.register("holy_blade", () -> new HolyBladeItem());
	public static final RegistryObject<Item> HOLY_STEEL_BLOCK = block(MaModBlocks.HOLY_STEEL_BLOCK, MaModTabs.TAB_MAGIC_RESOURSES);
	public static final RegistryObject<Item> HOLY_AXE_BLADE = REGISTRY.register("holy_axe_blade", () -> new HolyAxeBladeItem());
	public static final RegistryObject<Item> HOLY_GARD = REGISTRY.register("holy_gard", () -> new HolyGardItem());
	public static final RegistryObject<Item> UNCOMPLITE_HOLY_BLADE = REGISTRY.register("uncomplite_holy_blade", () -> new UncompliteHolyBladeItem());
	public static final RegistryObject<Item> HOLY_HAMMER = REGISTRY.register("holy_hammer", () -> new HolyHammerItem());
	public static final RegistryObject<Item> HOLY_HAMMER_OBSIDIANED = REGISTRY.register("holy_hammer_obsidianed",
			() -> new HolyHammerObsidianedItem());
	public static final RegistryObject<Item> EXCALIBUR = REGISTRY.register("excalibur", () -> new ExcaliburItem());
	public static final RegistryObject<Item> TRUE_EXCALIBUR = REGISTRY.register("true_excalibur", () -> new TrueExcaliburItem());
	public static final RegistryObject<Item> HOLY_KATANA = REGISTRY.register("holy_katana", () -> new HolyKatanaItem());
	public static final RegistryObject<Item> ICE_KATANA = REGISTRY.register("ice_katana", () -> new IceKatanaItem());
	public static final RegistryObject<Item> GUNGNIR = REGISTRY.register("gungnir", () -> new GungnirItem());
	public static final RegistryObject<Item> TRUE_GUNGNIR = REGISTRY.register("true_gungnir", () -> new TrueGungnirItem());
	public static final RegistryObject<Item> HOLY_BATTLE_AXE = REGISTRY.register("holy_battle_axe", () -> new HolyBattleAxeItem());
	public static final RegistryObject<Item> STONE_BATTLE_AXE = REGISTRY.register("stone_battle_axe", () -> new StoneBattleAxeItem());
	public static final RegistryObject<Item> HOLY_AXE = REGISTRY.register("holy_axe", () -> new HolyAxeItem());
	public static final RegistryObject<Item> HOLY_PICKAXE = REGISTRY.register("holy_pickaxe", () -> new HolyPickaxeItem());
	public static final RegistryObject<Item> HOLY_HOLY_CASTING_HAMMER = REGISTRY.register("holy_holy_casting_hammer",
			() -> new HolyHolyCastingHammerItem());
	public static final RegistryObject<Item> HEAVY_HOLY_ARMOR_HELMET = REGISTRY.register("heavy_holy_armor_helmet",
			() -> new HeavyHolyArmorItem.Helmet());
	public static final RegistryObject<Item> HEAVY_HOLY_ARMOR_CHESTPLATE = REGISTRY.register("heavy_holy_armor_chestplate",
			() -> new HeavyHolyArmorItem.Chestplate());
	public static final RegistryObject<Item> HEAVY_HOLY_ARMOR_LEGGINGS = REGISTRY.register("heavy_holy_armor_leggings",
			() -> new HeavyHolyArmorItem.Leggings());
	public static final RegistryObject<Item> HEAVY_HOLY_ARMOR_BOOTS = REGISTRY.register("heavy_holy_armor_boots",
			() -> new HeavyHolyArmorItem.Boots());
	public static final RegistryObject<Item> OBSIDIANED_HEVY_HOLY_ARMOR_HELMET = REGISTRY.register("obsidianed_hevy_holy_armor_helmet",
			() -> new ObsidianedHevyHolyArmorItem.Helmet());
	public static final RegistryObject<Item> OBSIDIANED_HEVY_HOLY_ARMOR_CHESTPLATE = REGISTRY.register("obsidianed_hevy_holy_armor_chestplate",
			() -> new ObsidianedHevyHolyArmorItem.Chestplate());
	public static final RegistryObject<Item> OBSIDIANED_HEVY_HOLY_ARMOR_LEGGINGS = REGISTRY.register("obsidianed_hevy_holy_armor_leggings",
			() -> new ObsidianedHevyHolyArmorItem.Leggings());
	public static final RegistryObject<Item> OBSIDIANED_HEVY_HOLY_ARMOR_BOOTS = REGISTRY.register("obsidianed_hevy_holy_armor_boots",
			() -> new ObsidianedHevyHolyArmorItem.Boots());
	public static final RegistryObject<Item> MANA_NECKLACE = REGISTRY.register("mana_necklace", () -> new ManaNecklaceItem());
	public static final RegistryObject<Item> MANA_BELT = REGISTRY.register("mana_belt", () -> new ManaBeltItem());
	public static final RegistryObject<Item> MANA_CHOCOLATE = REGISTRY.register("mana_chocolate", () -> new ManaChocolateItem());
	public static final RegistryObject<Item> MANA_CHOCOLATE_CHUNK = REGISTRY.register("mana_chocolate_chunk", () -> new ManaChocolateChunkItem());
	public static final RegistryObject<Item> VT_7 = REGISTRY.register("vt_7", () -> new VTE7Item());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
